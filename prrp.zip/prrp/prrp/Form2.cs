﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prrp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Owner.Show();//возвращение на первую форму
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked) { label1.Text = Properties.Resources.String3; pictureBox1.Image = Properties.Resources.k5; }//инф о док-х
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked) { label1.Text = Properties.Resources.String4; pictureBox1.Image = Properties.Resources.k6; }//инф о хобби
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)//перечень документов
        {
            if (comboBox1.SelectedIndex == 0) { pictureBox1.Image = Properties.Resources.k9; }
            if (comboBox1.SelectedIndex == 1) { pictureBox1.Image = Properties.Resources.k10; }
            if (comboBox1.SelectedIndex == 2) { pictureBox1.Image = Properties.Resources.k11; }
            if (comboBox1.SelectedIndex == 3) { pictureBox1.Image = Properties.Resources.k12; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 fr3 = new Form3();//переход на доп форму
            this.Hide();
            fr3.Show();
        }
    }
}
