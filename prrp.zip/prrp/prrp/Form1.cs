﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prrp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 fr2 = new Form2();//переход на вторую форму
            this.Hide();
            fr2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked) { label1.Text = Properties.Resources.String1; pictureBox1.Image = Properties.Resources.k8;}//информация о биографии
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked) { label1.Text = Properties.Resources.String2; pictureBox1.Image = Properties.Resources.k7; }//информация о физ. данных
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            Form2 fr2 = new Form2();
            fr2.Owner = this;//присваивание родительского класса
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //фио
            if (checkBox1.Checked) { textBox1.Text = "Мещерякова"; textBox2.Text = "Алиса"; textBox3.Text = "Александровна"; }
            else { textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = ""; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
