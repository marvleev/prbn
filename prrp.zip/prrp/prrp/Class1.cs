﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prrp
{
    class Class1:Form1
    {
        
        public static void rb1(RadioButton rbt, Form1 fr)//метод для 1го радиобатона
        {
            if (rbt.Checked) { }
            
        }    
    }
}
